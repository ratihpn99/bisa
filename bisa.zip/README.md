# Telegram Auto Order — Safe QR

## Run
```bash
unzip telegram-autoorder-atlantich2h-safeqr-final.zip
cd telegram-autoorder-atlantich2h-safeqr-final
cp .env.example .env
nano .env   # isi BOT_TOKEN, ADMIN_IDS, ATLANTIC_API_KEY
npm i
npm run start
```

## Notes
- Bot never sends URL photos to Telegram. It always renders QR from `qris_string` or downloads the image to buffer before sending.
- Make sure your server IP is **whitelisted** in AtlanticH2H, or invoice creation may fail with IP error.
